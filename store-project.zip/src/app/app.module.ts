import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ShoopComponent } from './pages/shop/shoop.component';
import { ShoppingCartComponent } from './pages/shopping-cart/shopping-cart.component';
import { NavBarComponent } from './pages/nav-bar/nav-bar.component';
import { ShopItemComponent } from './pages/shop-item/shop-item.component';
import { PaymentComponent } from './pages/Payment/Payment.component';

@NgModule({
  declarations: [
    AppComponent,
    ShoopComponent,
    ShoppingCartComponent,
    NavBarComponent,
    ShopItemComponent,
    PaymentComponent
  ],
  imports: [BrowserModule, FormsModule, AppRoutingModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
