import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from 'src/app/models/item';
import { Payment } from 'src/app/models/payment';
import { ItemService } from 'src/app/services/item.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.scss'],
})
export class ShoppingCartComponent implements OnInit {
  itemList: Item[] = [];
  itemCount: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  payment: Payment = new Payment();
  total: number = 0;
  constructor(private itemService: ItemService, private router: Router) {}

  ngOnInit() {
    this.itemList = this.itemService.getItemShoopCart();
    if (this.itemList.length > 0) {
      this.itemList.forEach((item) => {
        this.total = this.total + item.count * item.price;
      });
    }
  }

  onCartSave() {
    this.router.navigateByUrl('payment');
  }

  onCalculate() {
    this.total = 0;
    this.itemList.forEach((item) => {
      this.total = this.total + item.count * item.price;
    });
  }
}
