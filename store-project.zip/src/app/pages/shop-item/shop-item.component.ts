import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Item } from 'src/app/models/item';

@Component({
  selector: 'app-shop-item',
  templateUrl: './shop-item.component.html',
  styleUrls: ['./shop-item.component.scss'],
})
export class ShopItemComponent implements OnInit {
  @Input() selectedItem: Item;
  @Output() goShop = new EventEmitter<Item>();

  itemCount: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  constructor() {}

  ngOnInit() {}

  onGoShop(selectedItem: Item) {
    this.goShop.emit(selectedItem);
  }
}
