import { Component, OnInit } from '@angular/core';
import { Item } from 'src/app/models/item';
import { ItemService } from 'src/app/services/item.service';

@Component({
  selector: 'app-shoop',
  templateUrl: './shoop.component.html',
  styleUrls: ['./shoop.component.scss'],
})
export class ShoopComponent implements OnInit {
  hideItem = true;
  hideItemList = false;
  selectedItem: Item;
  itemList: Item[] = [];
  itemCount: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  constructor(private itemService: ItemService) {}

  ngOnInit() {
    var cartItems = this.itemService.getItemShoopCart();

    this.itemService.getItemList().subscribe((result) => {
      this.itemList = result;
      this.itemList.forEach((element) => {
        if (cartItems.length > 0) {
          var cartItem = cartItems.find((item) => item.id === element.id);
          if (cartItem === null || cartItem === undefined) {
            element.count = 0;
          } else {
            element.count = cartItem.count;
          }
        } else {
          element.count = 0;
        }
      });
    });
  }

  onIncreaseCount(id: number) {
    var currentItem = this.itemList.find((item) => item.id === id);
    if (currentItem.count < 10) {
      this.itemList.find((item) => item.id === id).count += 1;
    }

    currentItem = this.itemList.find((item) => item.id === id);
    var shoopCarItems = this.itemService.getItemShoopCart();
    var currentshoopCarItem = shoopCarItems.find(
      (item) => item.id === currentItem.id
    );

    if (currentshoopCarItem !== null && currentshoopCarItem !== undefined) {
      this.itemService.updateItemShoopCart(currentItem);
    } else {
      this.itemService.addItemShoopCart(currentItem);
    }
  }

  onShowItem(item: Item) {
    this.hideItem = !this.hideItem;
    this.hideItemList = !this.hideItemList;
    this.selectedItem = item;
  }

  onShowShop(selectedItem: Item) {
    debugger
    this.hideItem = !this.hideItem;
    this.hideItemList = !this.hideItemList;
     var index = this.itemList.findIndex((item) => item.id === selectedItem.id)
     this.itemList[index].count  = selectedItem.count;
  }

}
