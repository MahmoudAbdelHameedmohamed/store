export class Rating {
  rate: number;
  count: number;
}
