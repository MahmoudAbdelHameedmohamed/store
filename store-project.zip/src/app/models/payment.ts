export class Payment {
  name: string;
  address : string;
  creditCard :number;
}
