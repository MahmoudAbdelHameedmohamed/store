import { Injectable } from '@angular/core';
import { Observable, observable } from 'rxjs';
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
} from '@angular/common/http';
import { Item } from '../models/item';



@Injectable({
  providedIn: 'root',
})
export class ItemService {
  shoopCarItems: Item[] = [];

  constructor(private http: HttpClient) {}

  getItemList(): Observable<Item[]> {
    return this.http.get<Item[]>('https://fakestoreapi.com/products');
  }

  addItemShoopCart(Item) {

    this.shoopCarItems.push(Item);
  }

  updateItemShoopCart(_item :Item) {
    var index =  this.shoopCarItems.findIndex((item) => item.id === _item.id) ;
    this.shoopCarItems[index] = _item;
  }

  getItemShoopCart(): Item[] {

    return this.shoopCarItems;
  }
}
