import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentComponent } from './pages/Payment/Payment.component';
import { ShoopComponent } from './pages/shop/shoop.component';
import { ShoppingCartComponent } from './pages/shopping-cart/shopping-cart.component';



const routes: Routes = [
  { path: '', component: ShoopComponent },
  { path: 'Shopping-Cart', component: ShoppingCartComponent },
  { path: 'payment', component: PaymentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
